DROP TABLE ItemCategory;
DROP TABLE ItemBid;
DROP TABLE Item;
DROP TABLE Bidder;
DROP TABLE Seller;
